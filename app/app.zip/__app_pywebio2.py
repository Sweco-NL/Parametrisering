raise NotImplementedError()
from pywebio import start_server
from pywebio.input import *
from pywebio.output import *
from app_Drukpaal.drukpaal_app.app.text_to_floats import string_to_list_of_floats

def main():
    data = input_group("Basic info",[
        file_upload('dFoundations file', name='filename'),
        textarea("Ontgravingsniveaus",name="ontgravingsniveaus", code=True)
    ])
    put_text(string_to_list_of_floats(data["ontgravingsniveaus"]))

start_server(main, port=666, debug=True)


