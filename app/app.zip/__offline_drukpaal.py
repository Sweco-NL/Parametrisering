raise NotImplementedError
from dfoundations_lib.dfoundations import DFoundations
from copy import deepcopy

if __name__ == "__main__":
    dfoundations = DFoundations(r"C:\WebApplicatiesGeotechniek\app_Drukpaal\drukpaal_app_development\app\1.0 Fundex 380_450.foi")
    dfoundations.foi_file.types_bearing_piles.piles
    ontgravingsdieptes = (10.5, 10.0)
