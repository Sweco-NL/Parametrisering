raise NotImplementedError()
from itertools import product
from drukpaal_app.app.for_extractor import extract_for, calculate_for
import pandas as pd
from drukpaal_app.general.utilities import dfoundations_calc

import csv
import re
from pathlib import Path
from drukpaal_app.general.utilities import create_linear_list


class BearingPile:
    def bearing_block(self, bearing_lines):
        if bearing_lines is None:
            bearing_lines = "".join(self.__repr__())
        else:
            bearing_lines = "\n".join("".join(line) for line in bearing_lines)

        return f"""[POSITIONS - BEARING PILES]
[TABLE]
[COLUMN INDICATION]
index
X
Y
PileHeadLevel
Surcharge
LimitStateStrGeo
LimitStateService
PileName
[END OF COLUMN INDICATION]
[DATA]
{bearing_lines}
[END OF DATA]
[END OF TABLE]
[END OF POSITIONS - BEARING PILES]"""

    def __init__(self, data_line):
        data_split = list(csv.reader([data_line], delimiter=' ', skipinitialspace=True))[0]

        self._data_index = data_split[0]
        self._x = data_split[1]
        self._y = data_split[2]
        self._pileheadlevel = data_split[3]
        self._surcharge = data_split[4]
        self._limitstatestrgeo = data_split[5]
        self._limitstateservice = data_split[6]
        self._pilename = data_split[7]

    @property
    def data_index(self):
        return int(self._data_index)

    @data_index.setter
    def data_index(self, data_index: int):
        self._data_index = int(data_index)

    @property
    def x(self):
        return float(self._x)

    @x.setter
    def x(self, x: float):
        self._x = float(x)

    @property
    def y(self):
        return float(self._y)

    @y.setter
    def y(self, y: float):
        self._y = float(y)

    @property
    def pileheadlevel(self):
        return float(self._pileheadlevel)

    @pileheadlevel.setter
    def pileheadlevel(self, pileheadlevel: float):
        self._pileheadlevel = pileheadlevel

    @property
    def surcharge(self):
        return float(self._surcharge)

    @surcharge.setter
    def surcharge(self, surchage: float):
        self._surcharge = surchage

    @property
    def limitstatestrgeo(self):
        return float(self._limitstatestrgeo)

    @limitstatestrgeo.setter
    def limitstatestrgeo(self, limitstatestrgeo: float):
        self._limitstatestrgeo = limitstatestrgeo

    @property
    def limitstateservice(self):
        return float(self._limitstateservice)

    @limitstateservice.setter
    def limitstateservice(self, limitstateservice: float):
        self._limitstateservice = limitstateservice

    @property
    def pilename(self):
        return self._pilename.replace("'", "").strip()

    @pilename.setter
    def pilename(self, pilename: str):
        self._pilename = pilename.replace("'", "").strip()

    def __repr__(self):
        return fr"{self.data_index:>6d}" \
               fr"{self.x:>10.2f}" \
               fr"{self.y:>10.2f}" \
               fr"{self.pileheadlevel:>10.2f}" \
               fr"{self.surcharge:>10.2f}" \
               fr"{self.limitstatestrgeo:10.2f}" \
               fr"{self.limitstateservice:10.2f} '{self.pilename}'"


class Dfoundation_foi:
    def __init__(self, content):
        self._write_intermediate = None
        self._content = content
        self._calculation_pile_nr = None
        self._xi3 = None
        self._xi4 = None
        self._calculation_pile_type = None
        bearing_pile_lines = re.search(r"\[POSITIONS \- BEARING PILES\].*?"
                                       r"\[DATA\]\n"
                                       r"(?P<bearing_piles>.*?)"
                                       r"\n\[END OF DATA\].*?"
                                       r"\[END OF POSITIONS \- BEARING PILES\]", self.content, re.DOTALL).groupdict()

        self.bearing_piles = [BearingPile(line) for line in bearing_pile_lines["bearing_piles"].splitlines()]

        bearing_piles_block = re.search("\[TYPES - BEARING PILES\](.*?)\[END OF TYPES - BEARING PILES\]", content,
                                        re.DOTALL).group(0)

        self.pile_dict = {nr: pile for nr, pile in
                          enumerate(re.findall("(.*)\n\s*\d+\s+:\s+Pile type =", bearing_piles_block))}

    @property
    def write_intermediate(self):
        return self._write_intermediate

    @write_intermediate.setter
    def write_intermediate(self, write_intermediate: bool):
        self._write_intermediate = write_intermediate

    @property
    def preliminary_design_pile(self):
        if self._preliminary_design_pile:
            self._preliminary_design_pile = "Butt"
        return self._preliminary_design_pile

    @preliminary_design_pile.setter
    def preliminary_design_pile(self, preliminary_design_pile):
        self._preliminary_design_pile = preliminary_design_pile

    @property
    def calculation_pile_nr(self):
        if self._calculation_pile_nr is None:
            self.calculation_pile_type
        return self._calculation_pile_nr

    @calculation_pile_nr.setter
    def calculation_pile_nr(self, calculation_pile_nr: int):
        if self.pile_dict.get(calculation_pile_nr):
            self._calculation_pile_type = self.pile_dict.get(calculation_pile_nr)
            pile_name_line = "{paalnr:>5d} : Pile type = {paalnaam}".format(paalnr=calculation_pile_nr,
                                                                            paalnaam=self._calculation_pile_type)
            self.content = re.sub("\n(?P<start>.+: Pile type =.+)(?P<end>\n.+\n\[END OF PRELIMINARY DESIGN\])",
                                  f"\n{pile_name_line}\g<end>", self.content)
        self._calculation_pile_nr = calculation_pile_nr

    @property
    def calculation_pile_type(self):
        if self._calculation_pile_type is None:
            regex_pile_type_group = re.search(
                "\[PRELIMINARY DESIGN\]"
                ".*?"
                "[ ]+(?P<calculation_pile_nr>\d+)\s+: Pile type = (?P<pile_type>.*?)\n.*?"
                "\[END OF PRELIMINARY DESIGN\]",
                self.content, re.DOTALL)
            self._calculation_pile_type = regex_pile_type_group["pile_type"]
            self._calculation_pile_nr = regex_pile_type_group["calculation_pile_nr"]

        return self._calculation_pile_type

    @calculation_pile_type.setter
    def calculation_pile_type(self, calculation_pile_type: str):
        self._calculation_pile_type = calculation_pile_type

    @property
    def content(self):
        if hasattr(self, "bearing_piles"):
            self.bearing_piles[0].bearing_block(self.bearing_piles.__repr__())
        if isinstance(self.write_intermediate, bool):
            write_true = r"1 : Write intermediate results = TRUE"
            write_false = r"0 : Write intermediate results = FALSE"
            if self.write_intermediate:
                self._content = self._content.replace(write_false, write_true)
            elif not self.write_intermediate:
                self._content = self._content.replace(write_true, write_false)
        return self._content

    @content.setter
    def content(self, content):
        self._content = content

    @property
    def xi3(self):
        if self._xi3 is None:
            self._xi3 = float(re.search("\n\s+(?P<ksi3>\S+)\s+: Factor xi3", self.content)["ksi3"])
        return self._xi3

    @xi3.setter
    def xi3(self, xi3):
        self._xi3 = xi3

    @property
    def xi4(self):
        if self._xi4 is None:
            self._xi4 = float(re.search("\n\s+(?P<ksi4>\S+)\s+: Factor xi4", self.content)["ksi4"])
        return self._xi4

    @xi4.setter
    def xi4(self, xi4):
        self._xi4 = xi4

    @classmethod
    def read_foi_path(cls, path):
        return cls(Path(path).open().read())


def maken_varianten_lijst(ontgravingsniveaus: list, calc_folder: Path) -> list:
    """
    Uses the calc_folder to find the input_files. Iterates over the foi files and extracts the names of different piles.
    :param ontgravingsniveaus: A list of excavation depths
    :param calc_folder: The main folder for the calculation
    :return:
    """
    input_folder = calc_folder / "input_files"
    varianten_lijst = []
    for input_foi_path in input_folder.rglob("*.foi"):
        drukpaal = Dfoundation_foi(content=input_foi_path.open().read())

        varianten_lijst.extend([dict(drukpaal=drukpaal,
                               input_foi_path=input_foi_path,
                               ontgravingsniveau=ontgravingsniveau,
                               paalnr=paalnr,
                               paalnaam=paalnaam) for (paalnr, paalnaam), ontgravingsniveau in
                          product(drukpaal.pile_dict.items(), ontgravingsniveaus)])
    return varianten_lijst



def doorrekenen_paalberekeningen(calc_folder:Path, varianten_lijst:list, do_calc:bool=True) -> dict:
    """
    Calculate all the results based on the list with combinations created earlier.
    :param calc_folder: The base folder where the calculation is stored
    :param varianten_lijst: A list of dictionaries with drukpaal, foi_path, ontgravingsniveau, paalnr and paalnaam
    :param do_calc: Should the calculation be done
    :return:
    Returns a generator with dictionaries
    """

    output_folder = calc_folder / "output_folder"
    for nr, item in enumerate(varianten_lijst):
        # Select the drukpaal instance
        drukpaal = item["drukpaal"]
        # Set write intermediate results to True so that a for file is created.
        drukpaal.write_intermediate = True
        # Set the pile number for the calculation
        drukpaal.calculation_pile_nr = item["paalnr"]
        # Create a path to the folder for the calculation
        nr_folder = output_folder / f"{nr}"
        # Create the calculation folder
        nr_folder.mkdir(parents=True, exist_ok=True)
        # Create the name of the foi file
        output_foi_name = f'{item["ontgravingsniveau"]} {item["paalnaam"]}.foi'
        # Make sure to replace slashes in the name. Otherwise this would refer to a subfolder instead of the actual
        # file.
        output_foi_name = output_foi_name.replace("\\", " ").replace("/", " ")
        # Create the path for the foi file
        output_foi_path = nr_folder / output_foi_name
        output_fod_path = output_foi_path.with_suffix(".fod")
        output_for_path = output_foi_path.with_suffix(".for")
        # Write the foi file
        with output_foi_path.open("w+") as writefile:
            writefile.write(drukpaal.content)
        # Calculate the result of the file using dfoundations
        if do_calc:
            dfoundations_calc(nr_folder)
        # Check if has error_files
        has_error_files = bool(list(nr_folder.glob("*.err")))
        # Check if has error_files
        has_fod_files = bool(list(nr_folder.glob("*.fod")))

        yield {**item, **dict(has_error_files=has_error_files,
                              has_fod_files=has_fod_files,
                              nr_folder=nr_folder,
                              output_foi_path=output_foi_path,
                              output_for_path=output_for_path,
                              output_fod_path=output_fod_path)}

def extract_full_df(varianten_lijst, calc_folder, do_calc):
    for nr,result in enumerate(doorrekenen_paalberekeningen(varianten_lijst=varianten_lijst, calc_folder=calc_folder, do_calc=do_calc)):
        for_content = result["output_for_path"].open().read()
        for_df = extract_for(for_content)

        full_for_df = calculate_for(for_df)
        full_for_df["Ontgravingsniveau [m NAP]"] = result["ontgravingsniveau"]
        full_for_df["Paaltype [-]"] = result["paalnaam"]
        full_for_df["Fugt [kN]"] = result["drukpaal"].bearing_piles[0].limitstatestrgeo
        full_for_df["Fbgt [kN]"] = result["drukpaal"].bearing_piles[0].limitstateservice
        yield full_for_df, result

if __name__ == "__main__":
    # foi_path = Path(r"F:\webapp_data\drukpaal_app\2023_04_18_07_53_36\input_files\0\Paalberekeningen schuifbaan.foi")
    #
    #
    ontgravingsniveaus = create_linear_list(-1, -1, 0.5)

    calc_folder = Path(r"F:\webapp_data\drukpaal_app\2023_04_18_11_43_30")
    # calc_folder = Path(r"F:\webapp_data\drukpaal_app\2023_04_11_09_14_07")





    varianten_lijst = maken_varianten_lijst(ontgravingsniveaus=ontgravingsniveaus,calc_folder=calc_folder)

    aantal_berekeningen = len(varianten_lijst)

    print(f"Totaal aantal berekeningen : {aantal_berekeningen}")

    output_list = []


    for nr,(df,result) in enumerate(extract_full_df(varianten_lijst, calc_folder, do_calc=False),1):
        print(f"""Berekening {nr} van {aantal_berekeningen} word doorgerekend {result["output_foi_path"].name}""")
        output_list.append(df)



    output_df = pd.concat(output_list)
    print(output_df[['Fnk;d [kN]','Rc;net;d [kN]']])


    xlsx_path = calc_folder / "results.xlsx"

    output_df[['Foi name',
     'Ontgravingsniveau [m NAP]',
     'PPN [m NAP]',
     'Paaltype [-]',
     'Fugt [kN]',
     'Fbgt [kN]',
     'Rc;d [kN]',
     'Fnk;d [kN]',
     'Rc;net;d [kN]',
     's1;gem [m]',
     'sb;gem [m]',
     'var.coeff [%]',
     "CPT's [gebruikt]"]].to_excel(str(xlsx_path.absolute()))

    output_folder = calc_folder / r"output_folder"








