raise NotImplementedError()
import pandas as pd
from collections import defaultdict
from statistics import stdev, mean
from pprint import pprint
import numpy as np
import re
from pathlib import Path


def is_float(element) -> bool:
    if element is None:
        return False
    try:
        float(element)
        return True
    except ValueError:
        return False


def extract_for(content: str) -> dict:
    for_path = Path(re.search("FILENAME\s+:\s+(?P<path>.*)", content).groupdict()["path"])
    for_name = for_path.name
    ksi3 = float(re.search(r"NEN 9997-1:2016 tabel A.10: ksi3\s+=\s+(?P<ksi3>\S+)", content).groupdict()["ksi3"])
    ksi4 = float(re.search(r"NEN 9997-1:2016 tabel A.10: ksi4\s+=\s+(?P<ksi4>\S+)", content).groupdict()["ksi4"])

    output_list = []

    for item in re.finditer("Ontwerpberekening\s+(?P<ontwerpberekening>\d+)\s+met PPN = (?P<ppn>\S+) m.\s+\**\s+"
                            "(?P<grenstoestanden_blok>.*?)CONTROLE BIJ GRENSTOESTAND EQU.*?"
                            "BEREKENING NEGATIEVE KLEEF\s+---+.*?---+\n(?P<f_blok>.*?)\n---+(?P<ugt_blok>.*?)"
                            "bruikbaarheidsgrenstoestand.(?P<bgt_blok>.*?)Beta_dBruikbaarheid =", content, re.DOTALL):

        grenstoestanden_blok = item.groupdict()["grenstoestanden_blok"].strip()
        grenstoestand_dict = defaultdict(list)

        for grenstoestand in re.split("\n\n\s+", grenstoestanden_blok):
            data = re.search("SONDERING\s+(?P<cpt_name>.*?)\s+\(PPN\s\=\s+(?P<ppn>\S+)\s+m.\)"
                             ".*?"
                             "Rc;cal;max;i\s+\[kN\]\s+=\s+(?P<Rc_cal_max>\S+)\s+per sondering", grenstoestand,
                             re.DOTALL).groupdict()

            grenstoestand_dict["ppn"].append(float(data["ppn"]))
            grenstoestand_dict["Rc_cal_max"].append(float(data["Rc_cal_max"]))
            grenstoestand_dict["cpt_name"].append(data["cpt_name"])

        # A dictionary with the data for Fnk;d
        fnk_d_dict = defaultdict(list)

        for line in item.groupdict()["f_blok"].splitlines():
            if "NEE" in line:
                fnk_d = re.search(r"NEE\s+\S+\s+\S+\s+(?P<fnk_d>\S+)", line).groupdict()["fnk_d"].strip()
                cpt_name = re.search(r"(?P<cpt_name>.*?)\s+\d+\s+NEE", line).groupdict()["cpt_name"].strip()
                if is_float(fnk_d):
                    fnk_d = float(fnk_d)
                else:
                    fnk_d = 0
            elif "nvt" in line:
                cpt_name = re.search(r"^\s+(?P<cpt_name>.*?)\s+", line).groupdict()["cpt_name"].strip()
                fnk_d = 0
            else:
                raise NotImplementedError(f"Could not find Fnk;d for line {line}")


            fnk_d_dict["Fnk_d"].append(fnk_d)
            fnk_d_dict["cpt_name"].append(cpt_name)
            fnk_d_dict["for_name"].append(for_name)
            fnk_d_dict["ksi3"].append(float(ksi3))
            fnk_d_dict["ksi4"].append(float(ksi4))

        ugt_dict = defaultdict(list)

        for sub_blok in re.finditer("BIJ SONDERING\s+(?P<cpt_name>.*?)\n.*?sb\s+=\s+(?P<sb>\S+).*?s1\s+=\s+(?P<s1>\S+)",
                                    item.groupdict()["bgt_blok"],
                                    re.DOTALL):
            data = sub_blok.groupdict()
            ugt_dict["cpt_name"].append(data["cpt_name"])
            ugt_dict["sb"].append(float(data["sb"]))
            ugt_dict["s1"].append(float(data["s1"]))

        fnk_df = pd.DataFrame.from_dict(fnk_d_dict)
        grenstoestand_df = pd.DataFrame.from_dict(grenstoestand_dict)
        ugt_df = pd.DataFrame.from_dict(ugt_dict)
        fnk_grenstoestand_df = pd.merge(fnk_df, grenstoestand_df, on="cpt_name")
        ugt_fnk_grenstoestand_df = pd.merge(fnk_grenstoestand_df, ugt_df, on="cpt_name")

        output_list.append(ugt_fnk_grenstoestand_df)

    output_df = pd.concat(output_list)
    return output_df


def calculate_for(for_df):
    def bereken_variatie_coeff(df):
        return df["Rc_cal_max"].std() / df["Rc_cal_max"].mean()

    output_dict = defaultdict(list)

    for _, sub_df in for_df.groupby("ppn"):

        while len(sub_df) >= 2 and bereken_variatie_coeff(sub_df) > 0.12:
            sub_df = sub_df[sub_df["Rc_cal_max"] != sub_df["Rc_cal_max"].max()]
        variatie_coeff = bereken_variatie_coeff(sub_df)
        sub_df["variatie_coeff"] = variatie_coeff

        ksi3 = sub_df.iloc[0]["ksi3"]
        ksi4 = sub_df.iloc[0]["ksi4"]

        sb_gem = sub_df["sb"].mean()
        s1_gem = sub_df["s1"].mean()

        Rc_cal_max_gem = sub_df["Rc_cal_max"].mean()

        Rc_gem_ksi3 = Rc_cal_max_gem / ksi3

        Rc_min_ksi4 = min(sub_df["Rc_cal_max"].apply(lambda Rc_cal_max: Rc_cal_max / ksi4))

        Rc_d_ksi3 = Rc_gem_ksi3 / 1.2

        Rc_d_ksi4 = Rc_min_ksi4 / 1.2

        if Rc_gem_ksi3 < Rc_min_ksi4:
            Rc_d = Rc_d_ksi3
            fnk_d = sub_df["Fnk_d"].mean()
        else:
            Rc_d = Rc_d_ksi4
            fnk_d = sub_df[sub_df["Rc_cal_max"] == min(sub_df["Rc_cal_max"])]["Fnk_d"]

        cpt_name_str = ",".join(sub_df["cpt_name"].to_list())

        for_name = sub_df["for_name"].iloc[0]
        ppn = sub_df["ppn"].iloc[0]

        output_dict["Foi name"].append(for_name.replace(".for", ".foi"))
        output_dict["PPN [m NAP]"].append(ppn)
        output_dict["Rc;d [kN]"].append(int(round(Rc_d)))
        output_dict["Fnk;d [kN]"].append(int(round(fnk_d)))
        output_dict["Rc;net;d [kN]"].append(int(round(Rc_d - fnk_d)))
        output_dict["s1;gem [m]"].append(float(round(s1_gem, 3)))
        output_dict["sb;gem [m]"].append(float(round(sb_gem, 3)))
        output_dict["var.coeff [%]"].append(float(round(variatie_coeff * 100, 2)))
        output_dict["CPT's [gebruikt]"].append(cpt_name_str)

    output_df = pd.DataFrame.from_dict(output_dict).sort_values("PPN [m NAP]", ascending=False)
    return output_df


if __name__ == "__main__":
    foi_path = Path(r"F:\webapp_data\drukpaal_app\2023_04_03_10_43_00\clean19.foi")
    output_folder_name = foi_path.parts[3]
    input_folder = Path(*foi_path.parts[:4])
    errors_folder = Path(r"C:\Users\NLDVER_BD\Desktop\errors")
    output_folder = errors_folder / output_folder_name
    # import os

    from shutil import copytree
    copytree(input_folder, output_folder)


    # path = Path(r"F:\webapp_data\drukpaal_app\2023_07_03_09_59_46\output_folder\0\1.6 Prefab beton vk400.for")
    # path = Path(r"F:\webapp_data\drukpaal_app\2023_04_14_11_12_06\output_folder\0\-7.0 Prefab 320.for")
    # content = path.open().read()
    for_df = extract_for(content)
    # calculate_for(for_df)
    # print(for_df)
    # for i in extract_for(content):
    # print(i)
