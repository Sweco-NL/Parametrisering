raise NotImplementedError
from pathlib import Path
import re

# datetime_folder = Path(r"F:\webapp_data\drukpaal_app\2023_03_30_15_47_13")


class DFoundations:
    def __init__(self):
        self._path = None
        self._content = None

    @property
    def path(self):
        return self._path

    @path.setter
    def path(self, path: Path):
        self._path = Path(path)
        self._content = self._path.open().read()

    @property
    def content(self):
        return self._content

    @content.setter
    def content(self, content: str):
        self._content = content

datetime_folder= Path(r"F:\webapp_data\drukpaal_app\2023_04_03_10_29_11")

import numpy as np

start = 1
end = 5
stepsize = 0.5

def create_linear_list(start:float, end:float, stepsize:float, reverse=False):
    """ Create a list of floats starting at start, up to end with stepsize. The list can be reversed using the reverse statement.
    :param start: The start of the list
    :param end: The end of the list
    :param stepsize: The size of the steps
    :param reverse: Reverse the list
    :return:
    """
    diff = (end - start)
    num = diff / stepsize
    return sorted(np.linspace(start,end,round(num)+1).tolist(), reverse=reverse)

from random import randint
for i in range(20):
    start = randint(0,10)
    end =randint(start, 20)
    stepsize = 0.5



# for error_file in datetime_folder.glob("*.err"):
#     content = error_file.open().read()
#
# for foi_path in datetime_folder.rglob("*.foi"):
#     content = foi_path.open().read()


    # write_intermediate_false = r"0 : Write intermediate results = FALSE"
    # write_intermediate_true = r"1 : Write intermediate results = TRUE"
    # content = content.replace(write_intermediate_false, write_intermediate_true)
    # print(content)

    # if write_intermediate_false in content:
    #     print("a")
    # else:
    #     print('b')


    # dfoundat = DFoundations()
    # dfoundat.path = foi_path
    #
    # print(dfoundat.content)

    # print(re.search("(\S+)\s+:\s+Write intermediate results = (\S+)",content))


if __name__ == "__main__":
    # import shutil
    # shutil.make_archive(f"2023_04_07_15_09_54","zip" ,r"F:\webapp_data\drukpaal_app\2023_04_07_15_09_54")

    import zipfile

    # def create_zip_file(path, zip_path=None):
    #     if zip_path is None:
    #         zip_path = path / path.with_suffix(".zip").name
    #
    #     with zipfile.ZipFile(zip_path,"w", zipfile.ZIP_DEFLATED) as zipf:
    #
    #         for p in path.rglob("*.*"):
    #             if p.suffix != ".zip":
    #                 zipf.write(p, arcname=p.relative_to(path))
    #
    # date_folder = Path(r"F:\webapp_data\drukpaal_app\2023_04_07_15_09_54")
    # create_zip_file(date_folder)
    # import re
    #
    # content = Path(r"F:\webapp_data\drukpaal_app\2023_04_14_13_09_30\input_files\0\Drukpalen met afwijkende sondering.for").open().read()
    #
    # for item in re.finditer("Ontwerpberekening\s+(?P<ontwerpberekening>\d+)\s+met PPN = (?P<ppn>\S+) m.\s+\**\s+"
    #                       "(?P<grenstoestanden_blok>.*?)CONTROLE BIJ GRENSTOESTAND EQU.*?"
    #                       "BEREKENING NEGATIEVE KLEEF\s+---+.*?---+\n(?P<f_blok>.*?)\n---+(?P<ugt_blok>.*?)"
    #                       "bruikbaarheidsgrenstoestand.(?P<bgt_blok>.*?)Beta_dBruikbaarheid = 0", content, re.DOTALL):
    #     print(item["bgt_blok"])
    #     break
    for_path = Path(r"F:\webapp_data\drukpaal_app\2023_04_18_07_53_36\input_files\0\Paalberekeningen schuifbaan.for")

    content = for_path.open().read()
    for_iterator = re.finditer("Ontwerpberekening\s+(?P<cpt_naam>\S+)\s+met PPN =\s+(?P<paalpuntniveau>.*?)\s+m"
                               "(?P<ugt_blok>.*?)Beta_dBruikbaarheid = 0"
                               "(?P<bgt_blok>.*?)Beta_dBruikbaarheid = 0",content, re.DOTALL)

    for item in for_iterator:
        data_blok = item["data_blok"]

        break
        # print(re.findall(r"\s+s\s+\=\s+(?P<s>\S+)",data_blok))









