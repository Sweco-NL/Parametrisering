raise NotImplementedError
from jinja2 import Template
from flask import Flask, send_file
from drukpaal_app.app.app_pywebio import app_pywebio
from drukpaal_app.app.download_pywebio import download_pywebio
from pywebio.platform.flask import webio_view
from drukpaal_app.general.utilities import settings
import logging

logging.basicConfig(filename=f"{settings.path}.log",

                    level=logging.DEBUG,
                    format='%(asctime)s %(message)s')

# Setup app
app = Flask(__name__)


def application_maker(full_app_name: str,
                      pywebio_application,
                      methods: list = ["GET", "POST", "OPTIONS"]):
    """
    Add application to app.
    :param full_app_name: Name of the app
    :param pywebio_application: Pywebio function
    :param methods: Method for the app. Usually "GET", "POST", "OPTIONS"
    :return:
    Returns true if all went well.
    """
    app.add_url_rule(f"/{full_app_name}", f"{full_app_name}", webio_view(pywebio_application), methods=methods)
    return True


def main(debug=True):
    logging.info(f"Starting {settings.path} app")
    applications_settings = tuple([f"{settings.path}_app", app_pywebio, ["GET", "POST", "OPTIONS"]]), \
                            tuple([f"{settings.path}_download", download_pywebio, ["GET", "POST", "OPTIONS"]])

    @app.route("/")
    def main_app():
        template = Template("{% for path, _ , methods in applications_settings%}"
                            "<a href=\'{{path}}\'>{{path}}</a><br>"
                            "{% endfor %}").render(applications_settings=applications_settings)
        return template

    @app.route("/download_file/<file_date>")
    def download_file(file_date):
        zip_path = settings.app_folder / f"{file_date}" / f"{file_date}.zip"
        if zip_path.exists():
            return send_file(zip_path)
        else:
            return "File not found"
    for applications_setting in applications_settings:
        application_maker(*applications_setting)
    app.run(
        "10.240.0.253",
        # "0.0.0.0",
            port=settings.port,
            debug=debug)


if __name__ == "__main__":
    main(debug=True)
