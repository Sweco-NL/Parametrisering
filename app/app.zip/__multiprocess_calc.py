raise NotImplementedError
from multiprocessing import Pool
from pathlib import Path
from drukpaal_app.general.utilities import dfoundations_calc

def new_func(folder):
    dfoundations_calc(folder)
    print(folder)

if __name__ == "__main__":
    foi_paths = [foi_path.parent.absolute() for foi_path in
                 Path(r"F:\webapp_data\drukpaal_app\2023_04_03_12_29_44\output_folder").rglob("*.foi")][:10]
    # with Pool(5) as p:
    #     print(p.map(new_func, foi_paths))
    for foi_path in foi_paths:
        new_func(foi_path)