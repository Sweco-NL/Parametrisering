raise NotImplementedError()
from typing import Dict
import sys
import re
from pathlib import Path
from app_Drukpaal.drukpaal_app.app.drukpaal_offline import FOI


class FOR:
    def __init__(self, for_path: Path):
        self.path = for_path

    def foi_name(self):
        return self.path.stem

    @property
    def content(self):
        return self.path.open().read()

    @property
    def ontwerpberekeningen(self):
        output = []
        for item in re.finditer("Ontwerpberekening\s+(?P<ontwerpberekening>\d+)\s+met PPN = (?P<ppn>\S+) m.\s+\**\s+"
                                "(?P<grenstoestanden_blok>.*?)CONTROLE BIJ GRENSTOESTAND EQU.*?"
                                "BEREKENING NEGATIEVE KLEEF\s+---+.*?---+\n(?P<f_blok>.*?)\n---+(?P<ugt_blok>.*?)"
                                "bruikbaarheidsgrenstoestand.(?P<bgt_blok>.*?)Beta_dBruikbaarheid =",
                                self.content, re.DOTALL):
            output.append(Ontwerpberekening(item.group()))
        return output


class Ontwerpberekening:
    def __init__(self, ontwerpberekening_content):
        self.content = ontwerpberekening_content

    @property
    def paal_punt_niveau(self):
        search_paal_punt_niveau = re.search("(?P<ontwerpberekening>\d+)\s+met PPN = (?P<ppn>\S+) m.", self.content)
        if search_paal_punt_niveau is None:
            raise NotImplementedError("Paalpuntniveau niet gevonden in for bestand.")
        else:
            return float(search_paal_punt_niveau.groupdict()["ppn"])

    @property
    def paal_punt_index(self):
        search_paal_punt_niveau = re.search("(?P<ontwerpberekening>\d+)\s+met PPN = (?P<ppn>\S+) m.", self.content)
        if search_paal_punt_niveau is None:
            raise NotImplementedError("Paalpuntniveau niet gevonden in for bestand.")
        else:
            return int(search_paal_punt_niveau.groupdict()["ontwerpberekening"])

    @property
    def berekeningstoestanden(self):
        compiled_regex = re.compile(
            r"BEREKENING GRENSTOESTAND EQU BIJ SONDERING\s+(?P<sondering_naam>.+?)\s+\(PPN\s+=\s+(?P<paalpuntniveau>\S+) m\.\)\s+"
            r"\s+qc;I;gem\s+=\s+(?P<qc_i_gem>\S+)\s+qc;II;gem\s+=\s+(?P<qc_ii_gem>\S+)\s+qc;III;gem =\s+(?P<qc_iii_gem>\S+)\s+"
            r".*?Deq\s+=\s+(?P<Deq>\S+)\s+"
            r".*?alpha_p\s+=\s+(?P<alpha_p>\S+)\s+"
            r".*?beta\s+=\s+(?P<beta>\S+)\s+"
            r".*?s\s+=\s+(?P<s>\S+)\s+"
            r"\s+qb;max;i\s+\[kPa\]\s+=\s+(?P<qb_max_i_voor>\S+)\s+\(voor reductie tot 15 MPa\)\s+"
            r"qb;max;i\s+\[kPa\]\s+=\s+(?P<qb_max_i_na>\S+)\s+\(na reductie tot 15 MPa\)\s+"
            r"Rb;cal;max;i\s+\[kN\]\s+=\s+(?P<Rb_cal>\S+)\s+per sondering\s+"
            r"Rs;cal;max;i\s+\[kN\]\s+=\s+(?P<Rs_cal>\S+)\s+per sondering\s+"
            r"Rc;cal;max;i\s+\[kN\]\s+=\s+(?P<Rc_cal>\S+)", re.DOTALL)
        return list(Berekeningstoestand(i.groupdict()) for i in compiled_regex.finditer(self.content))


class Berekeningstoestand:
    def __init__(self, berekenings_dict: Dict):
        self.berekenings_dict = berekenings_dict

    @property
    def sondering_naam(self):
        return int(self.berekenings_dict["sondering_naam"])

    @property
    def paalpuntniveau(self):
        return float(self.berekenings_dict["paalpuntniveau"])

    @property
    def qc_i_gem(self):
        return float(self.berekenings_dict["qc_i_gem"])

    @property
    def qc_ii_gem(self):
        return float(self.berekenings_dict["qc_ii_gem"])

    @property
    def qc_iii_gem(self):
        return float(self.berekenings_dict["qc_iii_gem"])

    @property
    def Deq(self):
        return float(self.berekenings_dict["Deq"])

    @property
    def alpha_p(self):
        return float(self.berekenings_dict["alpha_p"])

    @property
    def beta(self):
        return float(self.berekenings_dict["beta"])

    @property
    def s(self):
        return float(self.berekenings_dict["s"])

    @property
    def qb_max_i_voor(self):
        return float(self.berekenings_dict["qb_max_i_voor"])

    @property
    def qb_max_i_na(self):
        return float(self.berekenings_dict["qb_max_i_na"])

    @property
    def Rb_cal(self):
        return float(self.berekenings_dict["Rb_cal"])

    @property
    def Rs_cal(self):
        return float(self.berekenings_dict["Rs_cal"])

    @property
    def Rc_cal(self):
        return float(self.berekenings_dict["Rc_cal"])


if __name__ == "__main__":
    output_folder = r"F:\webapp_data\drukpaal_app\2023_08_10_13_10_49\output_folder"
    output_path = Path(output_folder)
    for for_path in output_path.glob("*.for"):
        for_file = FOR(for_path)
        foi_file = FOI(for_path.with_suffix(".foi").open().read())
        # print(for_file.ontwerpberekeningen())
        for nr, ontwerpberkening in enumerate(for_file.ontwerpberekeningen):
            for berekeningstoestand in ontwerpberkening.berekeningstoestanden:
                print(berekeningstoestand.qb_max_i_na)
                print(berekeningstoestand.qb_max_i_voor)
                print(berekeningstoestand.s)
            sys.exit()
            # print(ontwerpberkening.paal_punt_index, ontwerpberkening.paal_punt_niveau)
            # print({"pile_name" : foi_file.preliminary_design.pile_name,
            #  "Fugt" : foi_file.positions_bearing_piles.limit_state_str_geo,
            #  "Fbgt" : foi_file.positions_bearing_piles.limit_state_service})
            # print(ontwerpberkening.content)
            # print(for_file.content)

            import sys
            # sys.exit()
