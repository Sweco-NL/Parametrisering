raise NotImplementedError()
import re
import os
import shutil
from pathlib import Path

output_folder = Path(r"C:\WebApplicatiesGeotechniek\app_Drukpaal\drukpaal_app\app\input_testing")

{"width can not be zero":4,
 "range check error": 41,
 "at least one cpt has to be selected": 38,
 "bottom of negative skin friction lies above excavation level": 12,
 "loads for limit states EQU/STR/GEO": 44,
 "select one pile":14,
 "loads smaller than or equal to 0": 42,
 "surface level below cpt":17,
 "no cpt selected":23}

output = {}
for nr, error_file in enumerate(Path(r"F:\webapp_data\drukpaal_app").glob("*\input_files\\0\\*.err")):
    with error_file.open() as readfile:
        output["\n".join(readfile.readlines()[10:])] = nr
for key,value in output.items():
    print(re.sub("\n\n+","\n",key), value)
    # output_file = output_folder / f"{nr}.foi"
    # foi_file = error_file.with_suffix(".foi")
    # print(foi_file)
    # shutil.copy(foi_file, output_file)
#
# os.system(
#     fr'cmd /c ""C:\Program Files (x86)\Deltares\D-Foundations 22.1.1\DFoundations.exe" /b '
#     fr'{output_folder}"')