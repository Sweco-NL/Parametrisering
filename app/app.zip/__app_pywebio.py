raise NotImplementedError
from drukpaal_app.app.drukpaal import Dfoundation_foi

import logging
from pathlib import Path
import pandas as pd
from drukpaal_app.app.drukpaal import maken_varianten_lijst , extract_full_df
# import json
from pywebio.input import *
from pywebio.output import *
from drukpaal_app.general.utilities import settings, create_zip_file
from drukpaal_app.app.app_header import general_app_header
from drukpaal_app.general.utilities import Current_date_time, dfoundations_calc, create_linear_list, cleanup_output_folder
from itertools import product
import numpy as np


def app_pywebio():
    # General header
    general_app_header(settings.app_name,
                       settings.versie,
                       settings.omschrijving,
                       validated=settings.gevalideerd
                       )

    put_link(f"Drukpaal download pagina",f"/drukpaal_download")
    # Upload form

    input_data = input_group("Drukpaal app", [
        file_upload("dFoundations file", name="input_files", required=True, accept=".foi", multiple=True),
        input("Bovenkant ontgravingsniveau [+m NAP]", name="bovenkant_ontgravingsniveau", required=True,
              type=FLOAT),
        input("Onderkant ontgravingsniveau [+m NAP]", name="onderkant_ontgravingsniveau", required=True,
              type=FLOAT)

    ])
    doorgaan_met_rekenen = True
    bovenkant_ontgravingsniveau = max(input_data["bovenkant_ontgravingsniveau"],
                                      input_data["onderkant_ontgravingsniveau"])
    onderkant_ontgravingsniveau = min(input_data["bovenkant_ontgravingsniveau"],
                                      input_data["onderkant_ontgravingsniveau"])

    current_date = Current_date_time(settings)

    # Parse all uploaded data.
    put_text("Opslaan input data")
    current_date.save_input_data(input_data)

    # Write uploaded_files data to input files
    put_text("Opslaan input bestanden")
    input_files = current_date.save_input_files(input_data["input_files"])

    # Prep input files
    # Make sure the file will write intermediate results

    write_intermediate_false = r"0 : Write intermediate results = FALSE"
    write_intermediate_true = r"1 : Write intermediate results = TRUE"
    for input_file in input_files:
        # Open the content op the input_files
        content = input_file.open().read()

        # Set the intermediate results to TRUE
        new_content = content.replace(write_intermediate_false, write_intermediate_true)

        # Check if the intermediate results are set to TRUE. If not stop the calculation.
        if write_intermediate_true not in new_content:
            put_error(f"{input_file.name} heeft geen intermediate results. Berekening word gestopt.")
            doorgaan_met_rekenen = False

        with input_file.open("w+") as writefile:
            writefile.write(new_content)

    # Batch proces data

    put_text("Controleren input bestanden")

    for uploaded_file_path in current_date.uploaded_file_paths:

        put_text(f"Contoleren van {uploaded_file_path.name} op aantal drukpalen in bestand.")

        dfoi = Dfoundation_foi(uploaded_file_path.open().read())

        if len(dfoi.bearing_piles) != 1:
            put_error(f"Het input bestand {uploaded_file_path.name} moet exact 1 paal bevatten. "
                     f"Deze berekening bevat {len(dfoi.bearing_piles)} palen")
            doorgaan_met_rekenen = False
            break
        else:
            put_text(f"Doorrekenen {uploaded_file_path.name}")
            uploaded_folder_path = uploaded_file_path.parent




            dfoundations_calc(uploaded_folder_path)

            # Check for error files and if found give back the content of the file.
            for error_file in uploaded_folder_path.glob("*.err"):
                put_error(f"--- Fout gevonden in {error_file.name} ---")
                error_content = error_file.open().read()
                put_error(error_content)
                doorgaan_met_rekenen = False
                break

            # FOR bestand zoeken

            # if [for_file for for_file in uploaded_folder_path.glob("*.for")]:
            #     put_info("for bestand gevonden")
            # else:
            #     put_error("Bij het berekenen van het input bestand is er geen FOR bestand aangetroffen. "
            #               "Zonder FOR bestanden kunnen geen resultaten worden berekend.")
            #     doorgaan_met_rekenen = False
            #     break
    doorgaan_met_rekenen = True
    if not doorgaan_met_rekenen:
        put_error("Berekening word gestopt.")
    else:
        put_text("Berekening word doorgezet")
        try:

            ontgravingsniveaus = create_linear_list(bovenkant_ontgravingsniveau, onderkant_ontgravingsniveau, stepsize=0.5)

            varianten_lijst = maken_varianten_lijst(ontgravingsniveaus=ontgravingsniveaus,
                                                    calc_folder=current_date.datetime_folder)

            aantal_berekeningen = len(varianten_lijst)

            put_text(f"Totaal aantal berekeningen : {aantal_berekeningen}")

            # Extract the results

            output_list = []
            for nr,(df,result) in enumerate(extract_full_df(varianten_lijst, current_date.datetime_folder, do_calc=True),1):
                put_text(f"""Berekening {nr} van {aantal_berekeningen} word doorgerekend {result["output_foi_path"].name}""")
                output_list.append(df)
        except Exception as e:
            print(e)

        # Save results in an excel file

        output_df = pd.concat(output_list)

        xlsx_name = input_files[0].with_suffix(".xlsx").name
        xlsx_path = current_date.datetime_folder / xlsx_name
        output_df[['Foi name',
                   'Ontgravingsniveau [m NAP]',
                   'PPN [m NAP]',
                   'Paaltype [-]',
                   'Fugt [kN]',
                   'Fbgt [kN]',
                   'Rc;d [kN]',
                   'Fnk;d [kN]',
                   'Rc;net;d [kN]',
                   's1;gem [m]',
                   'sb;gem [m]',
                   'var.coeff [%]',
                   "CPT's [gebruikt]"]].to_excel(xlsx_path, index=False)

        cleanup_output_folder(output_folder=current_date.output_folder)

        create_zip_file(current_date.datetime_folder)
        put_link(f"{current_date.datetime_zip.name}",f"/download_file/{current_date.datetime_string}")
        put_link(f"Drukpaal download pagina",f"/drukpaal_download")

    # Generate a graph if necessary

    # Zip all files

    # Create a link to the zip using flask to enhance download speed.


if __name__ == "__main__":
    app_pywebio()
